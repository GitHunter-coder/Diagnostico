@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py -3 diagnostico_agente.py --desinstalar-protocolo & goto fin)
where python >nul 2>nul && (python diagnostico_agente.py --desinstalar-protocolo & goto fin)
echo No se encontro Python.
:fin
pause
