@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py -3 diagnostico_agente.py --desinstalar-protocolo & exit /b)
where python >nul 2>nul && (python diagnostico_agente.py --desinstalar-protocolo & exit /b)
echo No se encontro Python.
pause
