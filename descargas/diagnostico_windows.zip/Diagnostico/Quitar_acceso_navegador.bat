@echo off
cd /d "%~dp0"
diagnostico_agente.exe --desinstalar-protocolo
pause
