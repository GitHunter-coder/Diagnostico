@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py -3 diagnostico_agente.py --cliente --registrar & exit /b)
where python >nul 2>nul && (python diagnostico_agente.py --cliente --registrar & exit /b)
echo No se encontro Python. Instalalo con: winget install Python.Python.3.12
pause
