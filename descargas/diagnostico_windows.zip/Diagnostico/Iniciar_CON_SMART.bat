@echo off
cd /d "%~dp0"
diagnostico_agente.exe --cliente --smart --registrar
if errorlevel 1 pause
