#!/bin/bash
cd "$(dirname "$0")"
sudo python3 diagnostico_agente.py --cliente --smart
