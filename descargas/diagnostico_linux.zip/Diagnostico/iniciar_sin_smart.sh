#!/bin/bash
cd "$(dirname "$0")"
python3 diagnostico_agente.py --cliente
